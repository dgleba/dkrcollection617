from django.contrib import admin
from django import forms

from . import models


class PostAdminForm(forms.ModelForm):

    class Meta:
        model = models.Post
        fields = "__all__"


class PostAdmin(admin.ModelAdmin):
    form = PostAdminForm
    list_display = [
        "created",
        "title",
        "last_updated",
        "body",
    ]
    readonly_fields = [
        "created",
        "title",
        "last_updated",
        "body",
    ]


admin.site.register(models.Post, PostAdmin)
