from django.views import generic
from django.urls import reverse_lazy
from . import models
from . import forms


class amodelListView(generic.ListView):
    model = models.amodel
    form_class = forms.amodelForm


class amodelCreateView(generic.CreateView):
    model = models.amodel
    form_class = forms.amodelForm


class amodelDetailView(generic.DetailView):
    model = models.amodel
    form_class = forms.amodelForm


class amodelUpdateView(generic.UpdateView):
    model = models.amodel
    form_class = forms.amodelForm
    pk_url_kwarg = "pk"


class amodelDeleteView(generic.DeleteView):
    model = models.amodel
    success_url = reverse_lazy("testapp_amodel_list")
