from rest_framework import serializers

from . import models


class amodelSerializer(serializers.ModelSerializer):

    class Meta:
        model = models.amodel
        fields = [
            "created",
            "last_updated",
        ]
