from django.urls import path, include
from rest_framework import routers

from . import api
from . import views


router = routers.DefaultRouter()
router.register("amodel", api.amodelViewSet)

urlpatterns = (
    path("api/v1/", include(router.urls)),
    path("testapp/amodel/", views.amodelListView.as_view(), name="testapp_amodel_list"),
    path("testapp/amodel/create/", views.amodelCreateView.as_view(), name="testapp_amodel_create"),
    path("testapp/amodel/detail/<int:pk>/", views.amodelDetailView.as_view(), name="testapp_amodel_detail"),
    path("testapp/amodel/update/<int:pk>/", views.amodelUpdateView.as_view(), name="testapp_amodel_update"),
    path("testapp/amodel/delete/<int:pk>/", views.amodelDeleteView.as_view(), name="testapp_amodel_delete"),

)
