from rest_framework import viewsets, permissions

from . import serializers
from . import models


class amodelViewSet(viewsets.ModelViewSet):
    """ViewSet for the amodel class"""

    queryset = models.amodel.objects.all()
    serializer_class = serializers.amodelSerializer
    permission_classes = [permissions.IsAuthenticated]
