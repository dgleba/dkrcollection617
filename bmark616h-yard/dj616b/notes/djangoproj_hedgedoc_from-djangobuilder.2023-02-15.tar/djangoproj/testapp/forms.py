from django import forms
from . import models


class amodelForm(forms.ModelForm):
    class Meta:
        model = models.amodel
        fields = []

